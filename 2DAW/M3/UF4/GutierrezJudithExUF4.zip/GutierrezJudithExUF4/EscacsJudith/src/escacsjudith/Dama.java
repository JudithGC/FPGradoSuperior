/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package escacsjudith;

/**
 *
 * @author guest-u2vik9
 */
public class Dama extends Pesa{
    //Atributs
    private static final String NOM="Dama";
    //Constructors

    /**
     * Constructor que utilitzem per initcialitzar les variables
     * @param color
     * @param posicio
     */
    public Dama(String color,PosicioTaulell posicio){
       super(color,posicio);
    }
   /* public Dama(PosicioTaulell posicio){
        
    }*/
    //Mètodes

    /**
     * Retorna
     * @return NOM
     */
    public static String getNOM() {
        return NOM;
    }
   /* @Override
    public boolean moure(PosicioTaulell posicio){
        
    }
    @Override
    public boolean menjar(Pesa pesa){
        
    }*/
}
