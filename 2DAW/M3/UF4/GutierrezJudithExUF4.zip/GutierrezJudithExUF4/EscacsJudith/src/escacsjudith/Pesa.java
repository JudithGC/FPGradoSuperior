package escacsjudith;

/**
 *
 * @author guest-u2vik9
 */
public class Pesa {
    //Atributs
    private String color;
    private PosicioTaulell posicio;
    private boolean mort=false;
    //Constructors

    /**
     * Constructor que utilitzem per initcialitzar les variables
     * @param color
     * @param posicio
     */
    public Pesa (String color,PosicioTaulell posicio){
        this.color=color;
        this.posicio=posicio;
    }
    //Mètodes

    /**
     * Retorna
     * @return color
     */
    public String getColor() {
        return color;
    }

    /**
     * Guarda
     * @param color
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * Retorna
     * @return posicio
     */
    public PosicioTaulell getPosicio() {
        return posicio;
    }

    /**
     * Guarda
     * @param posicio
     */
    public void setPosicio(PosicioTaulell posicio) {
        this.posicio = posicio;
    }
    
    /**
     * Guarda
     * @param fila
     * @param columna
     */
    public void setPosicio(int fila,int columna) {
        if(fila>1 && fila<9){
            System.out.println(fila);
        }else{
            System.out.println("");
        }
        if(columna>1 && columna<9){
            System.out.println(columna);
        }else{
            System.out.println("");
        }
    }

    /**
     * Mètode que retorna true si es mata a la peça
     * @return true
     */
    public boolean matar(){
       return mort=true;
    }

    /**
     * Aquest mètode hauria de retornar el nom
     * @return nom
     */
    public String getNom() {
       return "";
    }
 /*   public boolean moure(PosicioTaulell posicio){
        return "";
    }
    public boolean menjar(Pesa pesa){
        return "";
    }
*/    

    
}
