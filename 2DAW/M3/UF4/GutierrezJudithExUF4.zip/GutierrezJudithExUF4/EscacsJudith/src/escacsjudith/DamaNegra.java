/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package escacsjudith;

/**
 *
 * @author guest-u2vik9
 */
public class DamaNegra extends Dama{
    
    /**
     * Constructor que utilitzem per initcialitzar les variables
     * @param color
     * @param posicio
     */
    public DamaNegra(String color,PosicioTaulell posicio){
       super(color,posicio);
    }
    /*public DamaNegra(PosicioTaulell posicio){
        
    }*/
}
