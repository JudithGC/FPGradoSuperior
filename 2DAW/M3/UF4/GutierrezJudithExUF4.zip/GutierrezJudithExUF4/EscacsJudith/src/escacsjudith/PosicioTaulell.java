package escacsjudith;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author guest-u2vik9
 */
public class PosicioTaulell {
    //Atributs
    private int fila;
    private int columna;
    //Constructors

    /**
     * Constructor que utilitzem per initcialitzar les variables
     * @param fila
     * @param columna
     */
    public PosicioTaulell (int fila,int columna){
    this.fila=fila;
    this.columna=columna;
}
    //Mètodes

    /**
     * Retorna
     * @return fila
     */
    public int getFila() {
        return fila;
    }

    private void setFila(int fila) {
        if(fila<0){
            fila=0;
        }else {
        this.fila = fila;
        }
    }

    /**
     * Retorna
     * @return columna
     */
    public int getColumna() {
        return columna;
    }

    private void setColumna(int columna) {
        if(columna<0){
            columna=0;
        } else{
        this.columna = columna;
        }
    }
    
    /**
     * Hauria de retornar 
     * @return posicio
     */
    public String getPosicio(){
        return "";
    }

    /**
     * Retorna
     * @return color
     */
    public String getColor(){
        if(columna%2==0){
            return "B";
        }else{
        return "N";
        }
    }
    
}
