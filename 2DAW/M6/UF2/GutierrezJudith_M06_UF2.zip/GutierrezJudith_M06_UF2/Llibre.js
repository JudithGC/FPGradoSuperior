//Classe
fucntion Llibre(){
    var titol;
    var autor;
    var numPag =0;
}
//Constructora
function  Llibre (pTitol,pAutor){
    var titol = (typeof(pTitol)=="undefined" ? null: pTitol);
    var autor = (typeof(pAutor)=="undefined" ? null: pAutor);
    
    
    this.getAutor = function (){ return autor;}
    this.getTitol = function () { return titol;}
    this.setNumPag(pNumPag) = function () {
       var numPag = (typeof(pNumPag)=="undefined" ? null: pNumPag);
        numPag = (typeof(pNumPag)== "-" : pNumPag);
    }
    this.toString = function (){
        return toString(titol,numPag,autor);
    }
}
