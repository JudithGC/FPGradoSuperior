//Funcio intercanviar
var arrayIn;
var esquerra = 0;
var dreta = 0;

function intercanviar(arrayIn,esquerra,dreta){
    var temp;
    if (dreta==esquerra){
            temp = arrayIn(esquerra);
            arrayIn(esquerra) = arrayIn(dreta);
            arrayIn(dreta) = temp;
        return temp;
    }
}

//Funcio dividirArray

function dividirArray(arrayIn,esquerra,dreta,pivot){
    var punterE;
    var punterD;
    
    punterE = esquerra -1;
    punterD = dreta;
    
    while(true){
        do{
             punterE = punterE+1;
        } while (arrayIn(punterE)<pivot){
            do{
            punterD = punterD-1;
            } 
            while (punterD>0 && arrayIn(punterD)>pivot){
                    if(punterE>=punterD){
                        break;
                    } else {
                        intercanviar(arrayIn,punterE,punterD);
                    }
            }
        }
        
    }
    intercanviar(arrayIn,punterE,dreta);
    return punterE;
}

// Funcio ordenamentRapid

function ordenamentRapid(arrayIn,esquerra,dreta){
    var pivot;
    var particio;
    if(dreta- esquerra<=0){
        pivot = arrayIn(dreta);
        particio = dividirArray(arrayIn,esquerra,dreta,pivot);
        ordenamentRapid(arrayIn,esquerra,particio-1);
        ordenamentRapid(arrayIn,particio+1,dreta);
    }
}