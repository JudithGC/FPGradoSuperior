//Ordenar Per Titol
Llibre.prototype.ordenarPerTitol = function (){
    titol.sort();
}
//Ordenar Per Pagines
Llibre.prototype.ordenarPerPagines = function (){
     function ordenarPagines(a,b) { return (b-a);}
     document.write(numPag.sort(ordenarPagines));
}
//Ordenar Per Autor
Llibre.prototype.ordenarPerAutor = function (){
    function ordenarAutor(a,b) { return (b-a);}
    document.write(autor.sort(ordenarAutor));
}