var cadena1=prompt("Introdueix la primera paraula");
var cadena2=prompt("Introdueix la segona paraula");
var cadena3=prompt("Introdueix la tercera paraula");


var llargaria1 = cadena1.length;
var llargaria2 = cadena2.length;
var llargaria3 = cadena3.length;

//Llargaria 1
if (llargaria1<llargaria2 ){
     document.write("La paraula més llarga es : " +cadena2 +llargaria2);
    }
if(llargaria1<llargaria3){
    document.write("La paraula més llarga es:" +cadena3 +llargaria3);
}

//Llargaria 2
if(llargaria1>llargaria2){
     document.write("La paraula més llarga es : " +cadena1 +llargaria1);
}
if(llargaria1>llargaria3){
    document.write("La paraula més llarga es: " +cadena1 +llargaria1);
}
if(llargaria2>llargaria3){
    document.write("La paraula més llarga es: " +cadena2 +llargaria2);
} 
if (llargaria3>llargaria2){
    document.write("La paraula més llarga es: " +cadena3 +llargaria3);
}
